$(document).on('click', '.modal-submit', function(e){
    e.preventDefault();

    // Nascondi eventuali messaggi di errore precedenti
    $('.modal-error').hide();

    // Ottieni il form all'interno della modale
    var form = $(this).closest('.modal').find('form');

    // Effettua una richiesta AJAX per inviare il modulo
    $.ajax({
        type: form.attr('method'),
        url: form.attr('action'),
        data: form.serialize(),
        success: function(response) {
            // Controlla la risposta dal server
            if (response.success) {
                // Se il salvataggio è riuscito, puoi fare qualcosa, ad esempio ricaricare la pagina o eseguire altre azioni
                alert('Il prodotto è stato salvato con successo!');
                // Chiudi la modale
                $('#modal').modal('hide');
            } else {
                // Se il salvataggio non è riuscito, mostra eventuali messaggi di errore
                $('.modal-error').text(response.message).show();
            }
        },
        error: function(xhr, textStatus, errorThrown) {
            // In caso di errore durante la richiesta AJAX, mostra un messaggio generico di errore
            $('.modal-error').text('Si è verificato un errore durante l\'invio del modulo. Si prega di riprovare.').show();
        },
        complete: function() {
            // Nascondi l'indicatore di caricamento e mostra nuovamente il pulsante di invio
            $('#loading').hide();
            $('.modal-submit').show();
        }
    });
});
